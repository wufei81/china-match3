"""会话管理模块 - 实现临时表隔离的核心"""
import asyncio
import uuid
from datetime import datetime, timedelta
from typing import Dict, Set, Optional, Any
from dataclasses import dataclass, field
import logging

from ..core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class SessionInfo:
    """会话信息"""
    session_id: str
    user_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    last_accessed: datetime = field(default_factory=datetime.now)
    temp_tables: Set[str] = field(default_factory=set)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def is_expired(self, timeout: int) -> bool:
        """检查会话是否过期"""
        return (datetime.now() - self.last_accessed) > timedelta(seconds=timeout)
    
    def touch(self):
        """更新最后访问时间"""
        self.last_accessed = datetime.now()


class SessionManager:
    """
    会话管理器
    
    负责：
    1. 创建和管理用户会话
    2. 追踪每个会话的临时表
    3. 清理过期会话及其资源
    """
    
    def __init__(self):
        self._sessions: Dict[str, SessionInfo] = {}
        self._user_sessions: Dict[str, Set[str]] = {}  # user_id -> session_ids
        self._lock = asyncio.Lock()
        self._cleanup_task: Optional[asyncio.Task] = None
    
    async def start(self):
        """启动会话管理器"""
        logger.info("Session manager started")
        # 启动后台清理任务
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
    
    async def stop(self):
        """停止会话管理器"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        logger.info("Session manager stopped")
    
    async def create_session(
        self, 
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        创建新会话
        
        Args:
            user_id: 用户 ID（可选）
            metadata: 会话元数据
            
        Returns:
            session_id: 会话 ID
        """
        session_id = str(uuid.uuid4())
        
        async with self._lock:
            session_info = SessionInfo(
                session_id=session_id,
                user_id=user_id,
                metadata=metadata or {}
            )
            
            self._sessions[session_id] = session_info
            
            # 追踪用户会话
            if user_id:
                if user_id not in self._user_sessions:
                    self._user_sessions[user_id] = set()
                self._user_sessions[user_id].add(session_id)
            
            logger.info(f"Created session: {session_id} for user: {user_id}")
            return session_id
    
    async def get_session(self, session_id: str) -> Optional[SessionInfo]:
        """
        获取会话信息
        
        Args:
            session_id: 会话 ID
            
        Returns:
            SessionInfo 或 None
        """
        async with self._lock:
            session = self._sessions.get(session_id)
            if session:
                session.touch()
            return session
    
    async def register_temp_table(
        self, 
        session_id: str, 
        table_name: str
    ) -> bool:
        """
        注册临时表到会话
        
        Args:
            session_id: 会话 ID
            table_name: 临时表名称
            
        Returns:
            是否成功
        """
        async with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                logger.warning(f"Session not found: {session_id}")
                return False
            
            # 检查临时表数量限制
            if len(session.temp_tables) >= settings.session_max_temp_tables:
                logger.warning(
                    f"Session {session_id} exceeded max temp tables: "
                    f"{settings.session_max_temp_tables}"
                )
                return False
            
            session.temp_tables.add(table_name)
            logger.debug(f"Registered temp table: {table_name} in session: {session_id}")
            return True
    
    async def unregister_temp_table(
        self, 
        session_id: str, 
        table_name: str
    ) -> bool:
        """
        从会话注销临时表
        
        Args:
            session_id: 会话 ID
            table_name: 临时表名称
            
        Returns:
            是否成功
        """
        async with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return False
            
            session.temp_tables.discard(table_name)
            logger.debug(f"Unregistered temp table: {table_name} in session: {session_id}")
            return True
    
    async def get_session_tables(self, session_id: str) -> Set[str]:
        """
        获取会话的所有临时表
        
        Args:
            session_id: 会话 ID
            
        Returns:
            临时表名称集合
        """
        async with self._lock:
            session = self._sessions.get(session_id)
            return session.temp_tables.copy() if session else set()
    
    async def destroy_session(self, session_id: str) -> bool:
        """
        销毁会话（返回需要清理的表）
        
        Args:
            session_id: 会话 ID
            
        Returns:
            需要清理的临时表列表
        """
        async with self._lock:
            session = self._sessions.pop(session_id, None)
            if not session:
                return set()
            
            # 从用户会话映射中移除
            if session.user_id:
                user_sessions = self._user_sessions.get(session.user_id, set())
                user_sessions.discard(session_id)
                if not user_sessions:
                    self._user_sessions.pop(session.user_id, None)
            
            logger.info(f"Destroyed session: {session_id}")
            return session.temp_tables
    
    async def get_user_sessions(self, user_id: str) -> Set[str]:
        """
        获取用户的所有会话
        
        Args:
            user_id: 用户 ID
            
        Returns:
            会话 ID 集合
        """
        async with self._lock:
            return self._user_sessions.get(user_id, set()).copy()
    
    async def _cleanup_loop(self):
        """后台清理任务"""
        while True:
            try:
                await asyncio.sleep(settings.session_cleanup_interval)
                await self._cleanup_expired_sessions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup error: {e}", exc_info=True)
    
    async def _cleanup_expired_sessions(self):
        """清理过期会话"""
        expired_sessions = []
        
        async with self._lock:
            for session_id, session in list(self._sessions.items()):
                if session.is_expired(settings.session_timeout):
                    expired_sessions.append(session_id)
        
        if expired_sessions:
            logger.info(f"Cleaning up {len(expired_sessions)} expired sessions")
            for session_id in expired_sessions:
                tables = await self.destroy_session(session_id)
                # 返回需要清理的表（由调用方清理 DuckDB 表）
                # 这里可以触发一个事件或调用回调
    
    @property
    def active_sessions(self) -> int:
        """当前活跃会话数"""
        return len(self._sessions)


# 全局会话管理器实例
session_manager = SessionManager()