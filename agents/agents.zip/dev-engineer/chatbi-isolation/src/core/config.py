"""配置管理模块"""
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional
from functools import lru_cache


class Settings(BaseSettings):
    """应用配置"""
    
    # 应用配置
    app_name: str = "ChatBI Isolation Engine"
    app_version: str = "1.0.0"
    debug: bool = False
    
    # DuckDB 配置
    duckdb_database_path: str = Field(
        default=":memory:",
        description="DuckDB 数据库路径，:memory: 表示内存数据库"
    )
    duckdb_max_memory: str = Field(
        default="2GB",
        description="DuckDB 最大内存使用量"
    )
    duckdb_threads: int = Field(
        default=4,
        description="DuckDB 执行线程数"
    )
    duckdb_temp_directory: Optional[str] = Field(
        default=None,
        description="DuckDB 临时文件目录"
    )
    
    # Redis 配置
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis 连接 URL"
    )
    redis_password: Optional[str] = Field(
        default=None,
        description="Redis 密码"
    )
    redis_max_connections: int = Field(
        default=50,
        description="Redis 最大连接数"
    )
    
    # 缓存配置
    cache_default_ttl: int = Field(
        default=3600,
        description="默认缓存 TTL (秒)"
    )
    cache_session_ttl: int = Field(
        default=86400,
        description="会话缓存 TTL (秒)，默认 24 小时"
    )
    cache_query_result_ttl: int = Field(
        default=600,
        description="查询结果缓存 TTL (秒)，默认 10 分钟"
    )
    cache_table_schema_ttl: int = Field(
        default=1800,
        description="表结构缓存 TTL (秒)，默认 30 分钟"
    )
    
    # 会话配置
    session_timeout: int = Field(
        default=3600,
        description="会话超时时间 (秒)，默认 1 小时"
    )
    session_max_temp_tables: int = Field(
        default=100,
        description="每个会话最大临时表数量"
    )
    session_cleanup_interval: int = Field(
        default=300,
        description="会话清理间隔 (秒)，默认 5 分钟"
    )
    
    # 数据抽取配置
    extractor_batch_size: int = Field(
        default=10000,
        description="数据抽取批量大小"
    )
    extractor_max_rows: int = Field(
        default=1000000,
        description="单次抽取最大行数"
    )
    extractor_timeout: int = Field(
        default=300,
        description="数据抽取超时时间 (秒)"
    )
    
    # 查询配置
    query_timeout: int = Field(
        default=60,
        description="查询超时时间 (秒)"
    )
    query_max_rows: int = Field(
        default=100000,
        description="查询返回最大行数"
    )
    
    # 数据库连接配置
    database_url: Optional[str] = Field(
        default=None,
        description="主数据库连接 URL (用于元数据存储)"
    )
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()


# 导出配置实例
settings = get_settings()