# ChatBI 临时表隔离方案

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                         API Gateway                          │
│                    (FastAPI Router)                          │
└────────────────────┬────────────────────────────────────────┘
                     │
        ┌────────────┼────────────┐
        │            │            │
        ▼            ▼            ▼
┌───────────┐ ┌───────────┐ ┌──────────────┐
│  Session  │ │   Query   │ │    Data      │
│  Manager  │ │  Router   │ │  Extractor   │
└─────┬─────┘ └─────┬─────┘ └──────┬───────┘
      │             │              │
      └──────┬──────┴──────────────┘
             │
    ┌────────┴────────┐
    │                 │
    ▼                 ▼
┌────────┐       ┌────────┐
│ Redis  │       │ DuckDB │
│ (Cache)│       │(Engine)│
└────────┘       └────────┘
```

## 核心特性

1. **会话级隔离**: 每个用户会话拥有独立的 DuckDB 实例
2. **临时表管理**: 自动创建、追踪和清理临时表
3. **多层缓存**: Redis 缓存查询结果、表结构、元数据
4. **智能路由**: 根据查询类型路由到合适的引擎
5. **数据抽取**: 支持多种数据源接入

## 技术栈

- **Web框架**: FastAPI
- **数据库引擎**: DuckDB (嵌入式 OLAP)
- **缓存层**: Redis (Upstash Redis)
- **ORM**: SQLAlchemy (异步)
- **验证**: Pydantic
- **异步**: asyncio + aiocache

## 快速开始

```bash
# 安装依赖
pip install -r requirements.txt

# 启动服务
uvicorn src.main:app --reload
```

## 项目结构

```
chatbi-isolation/
├── src/
│   ├── core/              # 核心模块
│   │   ├── config.py      # 配置管理
│   │   ├── session.py     # 会话管理
│   │   └── exceptions.py  # 异常定义
│   ├── duckdb/           # DuckDB 引擎
│   │   ├── manager.py    # 引擎管理器
│   │   ├── isolation.py  # 隔离策略
│   │   └── query.py      # 查询执行
│   ├── cache/            # Redis 缓存层
│   │   ├── redis_client.py  # Redis 客户端
│   │   ├── strategies.py   # 缓存策略
│   │   └── invalidation.py  # 缓存失效
│   ├── extractor/        # 数据抽取服务
│   │   ├── base.py       # 基础抽取器
│   │   ├── postgres.py   # PostgreSQL 抽取
│   │   ├── mysql.py      # MySQL 抽取
│   │   └── file.py       # 文件抽取
│   ├── router/           # 查询路由
│   │   ├── analyzer.py   # 查询分析
│   │   ├── router.py     # 路由决策
│   │   └── executor.py   # 执行器
│   ├── api/              # API 接口
│   │   ├── v1/
│   │   │   ├── sessions.py   # 会话接口
│   │   │   ├── queries.py    # 查询接口
│   │   │   └── tables.py     # 表管理接口
│   │   └── dependencies.py   # 依赖注入
│   ├── models/           # 数据模型
│   │   ├── session.py   # 会话模型
│   │   ├── query.py     # 查询模型
│   │   └── table.py     # 表模型
│   ├── schemas/          # Pydantic 模型
│   │   ├── session.py
│   │   ├── query.py
│   │   └── table.py
│   └── main.py           # 应用入口
├── tests/                # 测试
├── requirements.txt
└── README.md
```